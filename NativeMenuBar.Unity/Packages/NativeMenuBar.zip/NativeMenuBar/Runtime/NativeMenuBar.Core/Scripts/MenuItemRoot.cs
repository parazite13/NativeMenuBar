using System;

namespace NativeMenuBar.Core
{
    [Serializable]
    public class MenuRootItem : AbstractMenuItem
    {
    }
}